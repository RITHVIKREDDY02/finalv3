#!/bin/bash

echo "🚀 Deploying Tashan Win VIP on VPS..."

# Set permissions
chmod +x build-production.sh
chmod +x deploy.sh

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Build production version
echo "🔨 Building production version..."
npm run build

# Build production server
echo "🔧 Building production server..."
npx esbuild server/index-production.ts --platform=node --packages=external --bundle --format=esm --outdir=dist --outfile=dist/index-production.js

echo "✅ Build complete!"

# Set environment variables
echo ""
echo "⚙️  Environment Setup:"
echo "For database storage (recommended):"
echo "export DATABASE_URL='postgresql://username:password@host:5432/database'"
echo ""
echo "For all deployments:"
echo "export NODE_ENV=production"
echo "export PORT=3000"
echo ""

# Start with PM2
echo "🚀 Starting application..."
echo "pm2 start dist/index-production.js --name 'tashan-win-vip' --env production"
echo "pm2 save"
echo ""

echo "🌐 Your app will be available at: http://your-vps-ip:3000"
echo "📊 Admin panel: http://your-vps-ip:3000/admin"

